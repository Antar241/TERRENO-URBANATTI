# Terranova — Análisis de Terrenos

Plataforma de análisis inmobiliario impulsada por IA para evaluar terrenos grandes,
estimar costos de urbanización y desarrollo, y calcular utilidades y ROI.

## Estructura del proyecto

```
terreno-app/
├── index.html          # Frontend principal
├── api/
│   └── analyze.js      # API route (proxy seguro a Anthropic)
├── vercel.json         # Configuración Vercel
└── README.md
```

## Deploy en Vercel (5 minutos)

### Opción A — Desde GitHub (recomendado)

1. Sube esta carpeta a un repositorio en GitHub
2. Ve a https://vercel.com → "Add New Project"
3. Importa tu repositorio
4. En "Environment Variables" agrega:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...` (tu API key de https://console.anthropic.com)
5. Clic en "Deploy"

### Opción B — Desde CLI

```bash
# Instalar Vercel CLI
npm i -g vercel

# Dentro de esta carpeta
vercel

# Agregar tu API key
vercel env add ANTHROPIC_API_KEY
# Pega tu sk-ant-... y presiona Enter

# Re-deploy con la variable configurada
vercel --prod
```

## Obtener tu API key

1. Ve a https://console.anthropic.com
2. API Keys → Create Key
3. Copia la clave (empieza con `sk-ant-`)
4. Agrégala en Vercel como variable de entorno

## Seguridad

- El API key NUNCA se expone en el frontend
- Todas las llamadas a Anthropic pasan por `/api/analyze.js` en el servidor
- Vercel cifra las variables de entorno automáticamente

## Dominio personalizado

En Vercel → Settings → Domains → Add Domain
Ejemplo: `terranova.tuempresa.com`

## Personalización

- Modifica colores en `index.html` dentro de `:root { ... }`
- Agrega tu logo reemplazando el texto "Terranova" en el `<header>`
- Ajusta el prompt en `api/analyze.js` para tu mercado específico
